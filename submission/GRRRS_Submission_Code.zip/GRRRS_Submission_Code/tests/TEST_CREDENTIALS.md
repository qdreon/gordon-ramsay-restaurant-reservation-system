# QA Test Credentials
**Do NOT commit to version control. Use for QA testing only.**

## Test Account 1: Mailtrap Verification (May 13, 2026)
- **Email:** mickel.castroverde0@gmail.com
- **Password:** TestPass$2026@GRR
- **Purpose:** Mailtrap email verification testing (legacy SendGrid/SMTP details are historical).
- **Created:** 2026-05-13T11:57:00Z
- **Status:** Active
- **Notes:** User can receive booking confirmation emails; verify inbox for message delivery.
