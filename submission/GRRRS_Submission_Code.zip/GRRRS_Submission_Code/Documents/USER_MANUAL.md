# Gordon Ramsay Restaurant Reservation System (GRRRS) — User Manual

> **Version:** 1.1  
> **Date:** May 14, 2026  
> **Project:** CPE 2201 — Software Design and Development  
> **Jira:** QDR-53 / Subtask 7.7  
> **Audience:** Restaurant Customers & Admin Staff (Front-of-House)

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Getting Started — Customer Portal](#2-getting-started--customer-portal)
   - 2.1 [Create an Account](#21-create-an-account)
   - 2.2 [Sign In](#22-sign-in)
   - 2.3 [Sign Out](#23-sign-out)
3. [Making a Reservation](#3-making-a-reservation)
   - 3.1 [Search for Available Tables](#31-search-for-available-tables)
   - 3.2 [Choose a Table Option](#32-choose-a-table-option)
   - 3.3 [Complete the Checkout](#33-complete-the-checkout)
   - 3.4 [Join the Waitlist (When Fully Booked)](#34-join-the-waitlist-when-fully-booked)
4. [Managing Your Reservation](#4-managing-your-reservation)
   - 4.1 [View Your Reservations](#41-view-your-reservations)
   - 4.2 [Cancel a Reservation](#42-cancel-a-reservation)
5. [Account Settings](#5-account-settings)
   - 5.1 [Update Your Profile](#51-update-your-profile)
   - 5.2 [Delete Your Account](#52-delete-your-account)
6. [Admin Dashboard](#6-admin-dashboard)
   - 6.1 [Accessing the Admin Area](#61-accessing-the-admin-area)
   - 6.2 [Floor Plan — Real-Time Table Overview](#62-floor-plan--real-time-table-overview)
   - 6.3 [Reservations Calendar](#63-reservations-calendar)
   - 6.4 [Guest CRM](#64-guest-crm)
   - 6.5 [Menu Management](#65-menu-management)
   - 6.6 [Waitlist Management](#66-waitlist-management)
   - 6.7 [System Health Widget](#67-system-health-widget)
7. [Operating Hours & Booking Rules](#7-operating-hours--booking-rules)
8. [Email Notifications](#8-email-notifications)
9. [Privacy & Data Rights](#9-privacy--data-rights)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. System Overview

The **Gordon Ramsay Restaurant Reservation System (GRRRS)** is a web-based platform that allows:

- **Customers** to search for available tables, book a reservation with a simulated deposit, view upcoming bookings, join a waitlist, and manage their account.
- **Admin staff** to monitor the restaurant floor plan in real time, manage the reservations calendar, maintain a guest CRM, update the digital menu, and control the waitlist queue.

The system enforces role-based access control (RBAC): customers can only access the Customer Portal (`/customer/*`) and admins can only access the Admin Dashboard (`/admin/*`).

---

## 2. Getting Started — Customer Portal

### 2.1 Create an Account

1. Navigate to the restaurant homepage (`/`).
2. Click **Register** in the top navigation bar, or go directly to `/auth/register`.
3. Fill in the registration form:
   - **Full Name** — your display name.
   - **Email Address** — must be a valid, unique email.
   - **Password** — minimum 8 characters.
   - **Dietary Restrictions** *(optional)* — e.g., vegetarian, gluten-free.
   - **Consent checkbox** — you must check **"I agree to the collection and use of my personal data for reservation management purposes"** (LEG-1 compliance). The form cannot be submitted without this.
4. Click **Create Account**.
5. You will be automatically signed in and redirected to the Customer Dashboard.

> **Note:** The system creates your profile automatically. No email verification step is required.

---

### 2.2 Sign In

1. Go to `/auth/login`.
2. Enter your registered **Email** and **Password**.
3. Click **Sign In**.
4. You will be redirected to your Customer Dashboard.

If you enter incorrect credentials, an error message will appear below the form.

---

### 2.3 Sign Out

1. From the Customer Dashboard, click **Sign Out** in the navigation bar.
2. Your session is cleared server-side and you are redirected to the homepage.

> **Security note:** The sign-out process completes server-side before the page navigates, preventing session leaks.

---

## 3. Making a Reservation

### 3.1 Search for Available Tables

1. From the homepage (`/`), locate the **Availability Search** form.
2. Fill in:
   - **Date** — the desired reservation date. Must be a future date. Dates outside operating hours or on blocked dates (holidays/private events) will show no availability.
   - **Time** — reservation start time. Must be within operating hours (**11:00 AM – 11:00 PM**). An error is shown for times outside this window.
   - **Party Size** — number of guests (minimum 1).
3. Click **Check Availability**.
4. The system queries the database via the availability RPC:
   - If tables are available, a list of **Table Options** appears below the form, showing table number(s), combined seating capacity, and a **"Reserve This Table"** button.
   - If no tables are available, a message is shown and the **Join Waitlist** button appears (see §3.4).

> **How table combinations work:** The system automatically suggests single tables, pairs, or triples of adjacent tables to fit your party size.

---

### 3.2 Choose a Table Option

1. Review the available options listed under **Availability Results**.
2. Each option shows:
   - Table number(s)
   - Total combined capacity
3. Click **Reserve This Table** on your preferred option.
4. A **Checkout Modal** opens immediately.

> **Important:** The table is NOT yet reserved at this point. It is only locked once you confirm payment in the next step.

---

### 3.3 Complete the Checkout

The Checkout Modal presents a **5-minute countdown timer**. You must complete payment within this window or the table selection will expire and return to the availability pool.

**Timer color codes:**
| Color | Meaning |
|-------|-------|
| GREEN | > 3 minutes remaining |
| YELLOW | 1-3 minutes remaining |
| RED | < 1 minute remaining |

**To confirm your booking:**
1. Verify the reservation summary (date, time, party size, table numbers, deposit amount).
2. Enter your simulated payment details:
   - **Card Number** — enter any 16-digit test number (e.g., `4111 1111 1111 1111`).
   - **Expiry** — MM/YY format.
   - **CVV** — 3-digit code.

   > **Security note (LEG-2):** No real card numbers are stored. The system tokenizes the payment data immediately and discards the raw number. Never enter a real credit card number.

3. Click **Confirm Booking**.

**Outcomes:**
- [OK] **Success:** You are redirected to the Customer Dashboard where your reservation appears under **Upcoming Reservations**.
- [WARN] **Table conflict:** If another customer claimed the same table in the same window, you will see a *"Table already reserved"* error. The modal stays open so you can close it and select a different option.
- [TIMEOUT] **Timer expired:** The modal closes automatically when the countdown reaches zero. Search again to see current availability.

A **booking confirmation email** is sent to your registered email address within 10 seconds of a successful booking, including a `.ics` calendar attachment.

---

### 3.4 Join the Waitlist (When Fully Booked)

If no tables are available for your requested date/time:
1. A **"Join Virtual Waitlist"** button appears below the search form.
2. Click it to open the Waitlist Modal.
3. Confirm or adjust the **date**, **time**, and **party size** shown in the modal.
4. Click **Join Waitlist**.
5. A confirmation message appears and the modal closes.

**What happens next:**
- You are placed in a queue for that date/time slot.
- If a confirmed reservation is cancelled, the waitlist system automatically sends you an **offer email** within minutes.
- You have a **10-minute window** to accept the offer before it is passed to the next person in the queue.

> **Note:** The waitlist has a maximum capacity of 50 parties per slot. If capacity is reached, the Join Waitlist button is disabled.

---

## 4. Managing Your Reservation

### 4.1 View Your Reservations

From the **Customer Dashboard** (`/customer/dashboard`):
- **Upcoming Reservations:** All confirmed reservations sorted by date (newest first).
- **Past / Cancelled Reservations:** Historical bookings for reference.

Each reservation card shows: Date, Time, Party Size, Table(s) assigned, and Status.

---

### 4.2 Cancel a Reservation

1. From the Customer Dashboard, find the reservation you wish to cancel under **Upcoming Reservations**.
2. Click the **Cancel** button on the reservation card.

**Cancellation rules:**
- Cancellations are only permitted **more than 2 hours before** the scheduled start time.
- The **Cancel** button is automatically disabled for reservations within 2 hours of their start time. Contact the restaurant directly in this case.

**What happens on cancellation:**
1. The reservation status changes to `cancelled`.
2. The reserved table(s) are immediately returned to the available pool.
3. The waitlist is notified automatically if anyone is queued for that slot.

---

## 5. Account Settings

### 5.1 Update Your Profile

From the Customer Dashboard, you can view your:
- Registered email address
- Account name

Profile editing (dietary restrictions, contact details) is managed via the admin CRM interface if requested.

---

### 5.2 Delete Your Account

> [WARNING] **This action is permanent and cannot be undone.**

1. From the Customer Dashboard, scroll to the bottom and click **Delete Account**.
2. A confirmation dialog appears asking you to confirm the deletion.
3. Click **Confirm Delete**.

**What is erased (LEG-1 — Right to Erasure):**
- Your customer profile record
- All your reservation history
- All waitlist entries
- Your Supabase authentication account

After deletion, your login credentials are permanently invalidated. Re-registering with the same email is possible as it creates an entirely new account.

---

## 6. Admin Dashboard

> **Access:** The Admin Dashboard is restricted to staff members with the `admin` role. Attempting to access `/admin/*` without admin credentials redirects to the login page (SEC-1 RBAC).

**Default admin route:** `/admin/dashboard`

---

### 6.1 Accessing the Admin Area

1. Navigate to `/auth/login`.
2. Sign in with your admin credentials (provided by the system administrator).
3. You are redirected to the **Admin Dashboard** at `/admin/dashboard`.

The admin navigation bar (top) provides links to all management sections.

---

### 6.2 Floor Plan — Real-Time Table Overview

**Route:** `/admin/floorplan`

The floor plan displays the 15 restaurant tables in a grid layout, colour-coded by live status:

| Colour | Table Status | Meaning |
|--------|-------------|---------|
| GREEN  | `available`  | Table is free and can be booked |
| YELLOW | `reserved`   | Table has a confirmed booking |
| RED    | `occupied`   | Guests are currently seated |
| GREY   | `dirty`      | Table needs clearing before next service |

**Real-time updates:**
- The floor plan subscribes to the database via **Supabase WebSockets**. Status changes made anywhere in the system (booking, arrival, completion) appear within 1–2 seconds without refreshing the page.

**Walk-in entry:**
- Click any **available** (green) table on the floor plan to open the **Walk-In Reservation** form.
- Enter the party size and confirm to create an instant `occupied` reservation.

**Offline warning (SAF-2):**
- If the network connection is lost, an **Offline Warning** banner appears at the top of the floor plan and all table interactions are disabled until connectivity is restored.

---

### 6.3 Reservations Calendar

**Route:** `/admin/reservations`

The admin calendar displays all reservations in a monthly view.

**Features:**
- **Month navigation:** Use the Previous/Next arrows to browse months.
- **New Reservation:** Click **New Reservation** to manually create a booking for a customer (useful for phone bookings).
- **Block Date:** Click **Block Date** to mark a date as unavailable (e.g., private events, holidays). Blocked dates prevent customers from making bookings online.
- **Operating hours validation:** The system rejects times outside 11:00 AM – 11:00 PM with an error message.

**Viewing reservations:**
- Each day shows a dot/indicator if reservations exist.
- Click a date to see the list of reservations for that day.

---

### 6.4 Guest CRM

**Route:** `/admin/crm`

The Guest CRM (Customer Relationship Management) table displays all registered customers.

**Columns:**
| Column | Description |
|--------|-------------|
| Name | Customer's full name |
| Email | Registered email address |
| Visits | Total number of completed reservations |
| No-Shows | Number of times a customer did not arrive |
| Dietary Restrictions | Stored preferences |
| Staff Notes | Internal notes (visible to admin only) |

**Editing a customer record:**
1. Click the **Edit** icon next to any customer row.
2. Update the **Allergy / Dietary Restrictions** or **Staff Notes** fields.
3. Click **Save** to apply changes, or **Cancel** to discard.

**No-show automation:**
- The system runs a scheduled job every 2 minutes. Reservations with a start time more than 30 minutes in the past that remain in `confirmed` status are automatically marked as no-shows and the customer's no-show count is incremented.

---

### 6.5 Menu Management

**Route:** `/admin/menu`

Admins can manage the digital menu displayed to customers on the homepage.

**Adding a menu item:**
1. Click **Add Item**.
2. Fill in: Item Name, Description, Price, Category (Starter/Main/Dessert/Drink).
3. Click **Save**.

**Editing a menu item:**
1. Click the **Edit** icon on any existing item.
2. Modify the fields as needed.
3. Click **Save**.

**Deleting a menu item:**
1. Click the **Delete** (trash) icon on any item.
2. Confirm the deletion in the dialog.

Changes to the menu are reflected immediately on the customer-facing homepage.

---

### 6.6 Waitlist Management

**Route:** `/admin/waitlist`

The waitlist queue page shows all customers currently waiting for a table.

**Columns:**
| Column | Description |
|--------|-------------|
| Customer | Name and email |
| Date / Time | Requested slot |
| Party Size | Number of guests |
| Status | `waiting`, `offered`, `accepted`, `declined`, `expired` |
| Joined At | When the customer joined the waitlist |

**Filters:**
- Use the **Status** filter dropdown to view specific queue states.
- Use the **Search** box to find a customer by name or email.

**Manual offer:**
- To manually send an offer to a waiting customer, click the **Send Offer** button on their row.
- The system sends them an email with a 10-minute acceptance window.

**Automatic offer:**
- When a reservation is cancelled, the system automatically triggers the next eligible customer in the waitlist queue.

---

### 6.7 System Health Widget

**Route:** `/admin/dashboard` (bottom section)

The **System Status** panel displays real-time health indicators for all integrated services:

| Service  | Indicator             | Description |
|----------|-----------------------|-------------|
| Database | [OK] / [ERROR]        | Supabase PostgreSQL connectivity |
| Email    | [OK] / [ERROR]        | Mailtrap email service status |
| Payments | [OK] / [ERROR]        | Simulated payment gateway status |

The widget polls the `/api/health` endpoint. If any service is degraded, the indicator turns red with an error message. Admins should contact the system administrator when a red indicator persists.

---

## 7. Operating Hours & Booking Rules

| Rule | Value |
|------|-------|
| Opening time | 11:00 AM |
| Closing time | 11:00 PM |
| Last booking | No later than closing time |
| Minimum advance booking | Same day allowed (subject to availability) |
| Default reservation duration | 2 hours |
| Checkout lock window | 5 minutes from table selection |
| Cancel deadline | At least 2 hours before start time |
| Waitlist capacity per slot | 50 parties maximum |

---

## 8. Email Notifications

The system sends automated emails for the following events:

| Event | Recipient | Content |
|-------|-----------|---------|
| Booking Confirmed | Customer | Reservation details + `.ics` calendar attachment |
| Waitlist Offer | Customer | Offer with 10-minute acceptance link |
| Booking Cancelled | Customer | Cancellation confirmation |

> **Technical note:** Email delivery uses the **Mailtrap** transactional email service. In a production deployment, the sender domain must have valid SPF/DKIM records configured. See DEF-003 in `Documents/defects_log.md` for DMARC considerations.

---

## 9. Privacy & Data Rights

GRRRS is designed to comply with applicable data privacy regulations (LEG-1):

- **Consent:** Account registration requires explicit consent for data collection and use.
- **Data stored:** Name, email, dietary restrictions, reservation history.
- **Data NOT stored:** Raw payment card numbers (PAN). Only tokenized payment references are retained (LEG-2 — PCI-DSS compliance).
- **Right to Erasure:** Customers can permanently delete their account and all associated data at any time via the **Delete Account** button on the Customer Dashboard. Deletion is immediate and irreversible.
- **Staff access:** Admin staff can view customer dietary restrictions and add internal notes. No other staff functionality modifies customer PII directly.

---

## 10. Troubleshooting

### "No tables available" when I expect them to be free
- Verify the date and time are within **operating hours** (11:00 AM – 11:00 PM).

> **Operational note:** The final Phase 7 sign-off checklist is tracked in [MASTER_TODO.md](MASTER_TODO.md). The remaining documentation-only items are HSTS confirmation, the manual restore drill, and traceability cleanup.
- Check that the date is not a **blocked date** (holiday or private event). Contact the restaurant directly.
- Try a different party size — smaller groups have more table combination options.

### My checkout timer expired before I could confirm
- The 5-minute window is strict to prevent holding tables indefinitely.
- Return to the homepage and search again — the table should be available again within 2 minutes (the automatic lock release runs every 2 minutes).

### I didn't receive a booking confirmation email
- Check your spam/junk folder.
- Ensure the email address on your account is correct.
- If using an institutional email (e.g., university), note that some domains have strict DMARC policies that may block external senders (see DEF-003).

### The cancel button is greyed out
- Cancellations are not permitted within 2 hours of the reservation start time. Contact the restaurant directly by phone for urgent cancellations.

### I can't access the Admin Dashboard
- Ensure you are signed in with an **admin** account. Regular customer accounts are blocked from `/admin/*` routes.
- If you believe you should have admin access, contact the system administrator.

### The floor plan shows "Offline Warning"
- Your network connection is unavailable. The floor plan will resume normal operation automatically when connectivity is restored. Check your internet connection.

### The Admin System Health widget shows a red indicator
- Contact the system administrator immediately. A red Database indicator may indicate Supabase is unreachable and bookings may not be processing correctly.

---

*End of User Manual — GRRRS v1.0*  
*Generated: May 13, 2026 | CPE 2201 — Software Design and Development*
